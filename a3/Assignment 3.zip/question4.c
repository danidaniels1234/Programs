// Accept one character from user and convert case of that character

// nahi aale;

#include<stdio.h>

void DisplayConvert(char cVal)
{
    if()
    {

    }
    else if()
    {

    }
}

int main()
{
    char cValue = '\0';

    printf("Enter a character: \n");
    scanf("%c",&cValue);
    
    DisplayConvert(cValue);

    return = 0;
}